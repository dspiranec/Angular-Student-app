export interface Student {
    id: number;
    jmbag: string;
    firstName: string;
    lastName: string;
    numberOfEcts: number;
    dateOfBirth: string;
    paidTuition: boolean
}