/*
import { Student } from './student';

export const STUDENTS: Student[] = [
    { jmbag: "0243235445", numberOfECTS: 120, tuitionShouldBePaid: true },
    { jmbag: "0243235337", numberOfECTS: 180, tuitionShouldBePaid: false },
    { jmbag: "0243235337", numberOfECTS: 230, tuitionShouldBePaid: false },
    { jmbag: "0243234432", numberOfECTS: 350, tuitionShouldBePaid: false }
];
*/