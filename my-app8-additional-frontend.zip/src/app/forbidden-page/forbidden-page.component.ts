import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forbidden-page',
  templateUrl: './forbidden-page.component.html'
})
export class ForbiddenPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
