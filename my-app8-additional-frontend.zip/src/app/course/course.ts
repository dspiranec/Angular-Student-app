export interface Course {
    name: string;
    numberOfEcts: number
}