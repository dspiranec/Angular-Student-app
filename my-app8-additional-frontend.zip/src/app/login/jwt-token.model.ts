export class JwtToken {
    token: string;
}
